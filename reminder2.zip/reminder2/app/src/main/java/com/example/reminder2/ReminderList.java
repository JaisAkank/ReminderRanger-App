package com.example.reminder2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.content.Intent;
import android.os.Bundle;
import android.app.PendingIntent;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.material.switchmaterial.SwitchMaterial;


public class ReminderList extends AppCompatActivity {
    TextView txt, txt_time_date;
    AlarmManager alarmManager;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder_list);

        txt = findViewById(R.id.remindertext);
        txt_time_date = findViewById(R.id.remindertimedate);
        SwitchMaterial reminderSwitch = findViewById(R.id.reminderSwitch);

        String rem = getIntent().getStringExtra("reminderTxt");
        String remd = getIntent().getStringExtra("remDate");
        String remt = getIntent().getStringExtra("remTime");

        txt.setText(rem);
        txt_time_date.setText(remt + " " + remd);

        // Set the listener for the switch
        reminderSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (!isChecked) {
                    // If switch is unchecked, set the alarm
                    cancelAlarm();
                } else {
                    // If switch is checked, cancel the alarm
                    setAlarm();
                }
            }
        });

        ImageButton closeButton = findViewById(R.id.BackButton);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    // Method to set the alarm
    public void setAlarm() {
        // Get the requestCode from the intent extras
        int requestCode = getIntent().getIntExtra("requestCode", -1);
        String reminderText = getIntent().getStringExtra("reminderTxt");

        // Create a new intent with the same requestCode as the one used to set the alarm
        Intent intent = new Intent(getApplicationContext(), ReminderBroadcastReceiver.class);
        intent.putExtra("reminderTxt", reminderText);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(), requestCode, intent, PendingIntent.FLAG_MUTABLE);

        // Get the AlarmManager instance
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

        // Set the alarm to go off at the specified time
        long timeInMillis = getIntent().getLongExtra("timeInMillis", -1);
        if (timeInMillis != -1) {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent);
        }

        // Display a toast to confirm that the reminder has been set
        Toast.makeText(getApplicationContext(), "Reminder set", Toast.LENGTH_SHORT).show();
    }

    // Method to cancel the alarm
    public void cancelAlarm() {
        // Get the requestCode from the intent extras
        int requestCode = getIntent().getIntExtra("requestCode", -1);

        // Create a new intent with the same requestCode as the one used to set the alarm
        Intent intent = new Intent(getApplicationContext(), ReminderBroadcastReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(), requestCode, intent, PendingIntent.FLAG_MUTABLE);

        // Get the AlarmManager instance
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

        // Cancel the pending intent
        alarmManager.cancel(pendingIntent);

        // Display a toast to confirm that the reminder has been canceled
        Toast.makeText(getApplicationContext(), "Reminder cancelled", Toast.LENGTH_SHORT).show();
    }
}

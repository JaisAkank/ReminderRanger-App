package com.example.reminder2;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.material.switchmaterial.SwitchMaterial;

public class DisplayReminderActivity extends AppCompatActivity {
    MediaPlayer mediaPlayer;
    TextView reminderTextView;
    ImageView image;
    SwitchMaterial reminderToggleButton;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_reminder);

        image = findViewById(R.id.img);
        Glide.with(this).asGif().load(R.raw.bell).into(image);

        // Maximizing the volume
        AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        int maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, maxVolume, 0);


        // playing the sound of alarm when the reminder text appears
        mediaPlayer = MediaPlayer.create(DisplayReminderActivity.this, R.raw.alarm);
        mediaPlayer.setLooping(true);
        mediaPlayer.start();

        // Get the reminder text and reminder ID from the intent
        String reminderText = getIntent().getStringExtra("REMINDER_TEXT");
        int reminderId = getIntent().getIntExtra("REMINDER_ID", -1);

        // Set the reminder text on the TextView
        reminderTextView = findViewById(R.id.reminder_text_view);
        reminderTextView.setText(reminderText);

        // Set a click listener on the Close button to finish the activity
        ImageButton closeButton = findViewById(R.id.close_button);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer.stop();
                finish();
            }
        });
    }
}

package com.example.reminder2;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
public class MainActivity extends AppCompatActivity {

    private EditText reminderEditText;
    PendingIntent pendingIntent;
    Calendar selectedDateTime;
    String reminder;
    int requestCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        reminderEditText = findViewById(R.id.reminderEditText);

        ImageButton setReminderButton = findViewById(R.id.setReminderButton);
        setReminderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                reminder = reminderEditText.getText().toString();
                if (reminder.equals("")) {
                    Toast.makeText(MainActivity.this, "Please specify the reminder text!", Toast.LENGTH_SHORT).show();
                } else {
                    DatePicker datePicker = findViewById(R.id.datePicker);
                    TimePicker timePicker = findViewById(R.id.timePicker);
                    int day = datePicker.getDayOfMonth();
                    int month = datePicker.getMonth();
                    int year = datePicker.getYear();

                    int hour = timePicker.getHour();
                    int minute = timePicker.getMinute();

                    selectedDateTime = Calendar.getInstance();
                    selectedDateTime.set(year, month, day, hour, minute);
                    selectedDateTime.set(Calendar.SECOND, 0); // set seconds to 0
                    selectedDateTime.set(Calendar.MILLISECOND, 0); // set milliseconds to 0

                    if (selectedDateTime.getTimeInMillis() <= System.currentTimeMillis()) {
                        Toast.makeText(MainActivity.this, "Please select a future date and time", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    long reminderTime = selectedDateTime.getTimeInMillis();

                    Intent intent = new Intent(MainActivity.this, ReminderBroadcastReceiver.class);
                    intent.putExtra("reminder", reminder);

                    requestCode = (int) System.currentTimeMillis();
                    pendingIntent = PendingIntent.getBroadcast(MainActivity.this, requestCode, intent, PendingIntent.FLAG_MUTABLE);

                    AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminderTime, pendingIntent);
                    } else {
                        alarmManager.setExact(AlarmManager.RTC_WAKEUP, reminderTime, pendingIntent);
                    }

                    Toast.makeText(MainActivity.this, "Reminder set for " + DateFormat.getTimeInstance().format(selectedDateTime.getTime()), Toast.LENGTH_LONG).show();
                    reminderEditText.setText("");
                }
            }
        });

        ImageButton viewReminderButton = findViewById(R.id.viewReminderButton);
        viewReminderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selectedDateTime == null || selectedDateTime.getTimeInMillis() <= System.currentTimeMillis()) {
                    Toast.makeText(MainActivity.this, "No reminders set yet", Toast.LENGTH_SHORT).show();
                    return;
                } else {
                    Intent intent1 = new Intent(MainActivity.this, ReminderList.class);
                    intent1.putExtra("reminderTxt", reminder);
                    intent1.putExtra("remDate",  DateFormat.getDateInstance().format(selectedDateTime.getTime()));
                    intent1.putExtra("remTime",  DateFormat.getTimeInstance().format(selectedDateTime.getTime()));
                    intent1.putExtra("requestCode", requestCode);
                    startActivity(intent1);
                }
            }
        });
    }
}

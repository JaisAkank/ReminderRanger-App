package com.example.reminder2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ReminderBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String reminderText = intent.getStringExtra("reminder");

        // Get the state of the toggle button from the intent
        boolean isToggleOn = intent.getBooleanExtra("toggleState", true);

        // Create an intent to start the activity to display the reminder text
        Intent displayIntent = new Intent(context, DisplayReminderActivity.class);
        displayIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        displayIntent.putExtra("REMINDER_TEXT", reminderText);
//        displayIntent.putExtra("TOGGLE_STATE", isToggleOn);
        displayIntent.putExtra("TOGGLE_STATE", isToggleOn);

        // Start the activity to display the reminder text
        context.startActivity(displayIntent);
    }
}
